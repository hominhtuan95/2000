@echo off
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --onefile --windowed --name GiaoDienChanDoan --add-data "header.png;." --add-data "forest_background.png;." GiaoDienChanDoan.py
pause
